## 第三十四届“冯如杯”竞赛主赛道论文

本模板是为第三十四届“冯如杯”竞赛主赛道设计的Latex模板，基于以下作品
改进而来，将作为官方模板供同学们使用。

后续更新请关注[发布仓库](https://github.com/Hello-2073/The-33rd-Fengru-Cup-Template)，感谢本模板历届作者[Somedaywilld](https://github.com/Somedaywilldo/Someday-XeLaTex-Template)，[cpfy](https://github.com/cpfy/FRB_template.git)，

## 使用方法
本模板主文件为FRBTemplate.tex，请使用XeLatex编译。

